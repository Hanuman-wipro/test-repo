package pl.grzejszczak.marcin.camel.service;

public interface EnrichingService {
	void enrich();
}
