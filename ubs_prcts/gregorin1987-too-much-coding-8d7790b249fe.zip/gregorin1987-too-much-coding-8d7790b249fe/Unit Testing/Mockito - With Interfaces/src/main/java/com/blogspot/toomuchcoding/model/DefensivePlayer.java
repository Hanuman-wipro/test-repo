package com.blogspot.toomuchcoding.model;

/**
 * User: mgrzejszczak
 * Date: 09.06.13
 * Time: 15:44
 */
public interface DefensivePlayer extends Player {
    void defend();
}
