package com.blogspot.toomuchcoding.model;

/**
 * User: mgrzejszczak
 * Date: 09.06.13
 * Time: 22:19
 */
public interface DJ {
    void playSomeMusic();
}
