package com.blogspot.toomuchcoding.model;

/**
 * User: mgrzejszczak
 * Date: 09.06.13
 * Time: 15:44
 */
public interface Player {
    void run();
}
