package com.blogspot.toomuchcoding.model;

/**
 * User: mgrzejszczak
 * Date: 09.06.13
 * Time: 22:20
 */
public interface JavaDeveloper {
    void doSomeSeriousCoding();
}
