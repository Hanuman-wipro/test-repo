package pl.grzejszczak.marcin.postprocessor;

public interface SomeOtherService {
	void methodC();

	void methodD();
}
