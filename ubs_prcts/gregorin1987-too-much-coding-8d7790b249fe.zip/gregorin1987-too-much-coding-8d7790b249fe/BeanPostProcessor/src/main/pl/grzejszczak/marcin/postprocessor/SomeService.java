package pl.grzejszczak.marcin.postprocessor;

public interface SomeService {
	void methodA();

	void methodB();
}
