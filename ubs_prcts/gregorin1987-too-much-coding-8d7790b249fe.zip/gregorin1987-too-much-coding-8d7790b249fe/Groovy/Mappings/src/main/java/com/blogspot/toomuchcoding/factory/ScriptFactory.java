package com.blogspot.toomuchcoding.factory;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: mgrzejszczak
 * Date: 30.03.13
 * Time: 16:56
 */
public interface ScriptFactory {
    File createScript();
}
