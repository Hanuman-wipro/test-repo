package com.blogspot.toomuchcoding.compilestatic

class DynamicPlayer {
    static final String ORIGINAL_RESULT = "bar"
    
    def unknownType = ORIGINAL_RESULT
}
