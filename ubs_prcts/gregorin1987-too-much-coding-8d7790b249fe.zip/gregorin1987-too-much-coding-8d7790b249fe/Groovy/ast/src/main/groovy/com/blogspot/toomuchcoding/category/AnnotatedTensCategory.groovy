package com.blogspot.toomuchcoding.category

@Category(Integer)
class AnnotatedTensCategory {
    Integer getAnnotatedTens() {
        return this * 10
    }
}
