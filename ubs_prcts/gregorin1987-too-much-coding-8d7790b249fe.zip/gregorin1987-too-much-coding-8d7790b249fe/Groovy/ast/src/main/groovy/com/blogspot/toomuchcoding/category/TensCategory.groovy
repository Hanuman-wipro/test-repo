package com.blogspot.toomuchcoding.category

class TensCategory {
    static Integer getTens(Integer self) {
        return self * 10
    }
}
