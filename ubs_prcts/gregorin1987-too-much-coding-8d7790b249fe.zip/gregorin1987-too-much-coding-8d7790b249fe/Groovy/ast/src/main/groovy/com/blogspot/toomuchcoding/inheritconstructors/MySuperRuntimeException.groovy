package com.blogspot.toomuchcoding.inheritconstructors

import groovy.transform.InheritConstructors

@InheritConstructors
class MySuperRuntimeException extends RuntimeException {

}
