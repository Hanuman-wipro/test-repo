package com.blogspot.toomuchcoding.delegate

class DelegatePlayer {
    String name, surname
    @Delegate
    BigDecimal value
}
