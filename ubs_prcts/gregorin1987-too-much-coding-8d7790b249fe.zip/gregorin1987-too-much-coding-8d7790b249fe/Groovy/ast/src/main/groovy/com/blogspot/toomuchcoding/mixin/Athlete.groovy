package com.blogspot.toomuchcoding.mixin

interface Athlete {
    String getName()
}
