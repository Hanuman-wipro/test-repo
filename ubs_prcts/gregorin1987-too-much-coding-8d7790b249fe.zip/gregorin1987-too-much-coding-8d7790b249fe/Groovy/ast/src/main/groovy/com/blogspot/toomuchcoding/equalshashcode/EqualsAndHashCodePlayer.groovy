package com.blogspot.toomuchcoding.equalshashcode
import groovy.transform.EqualsAndHashCode

@EqualsAndHashCode
class EqualsAndHashCodePlayer {
    String name, surname
}
