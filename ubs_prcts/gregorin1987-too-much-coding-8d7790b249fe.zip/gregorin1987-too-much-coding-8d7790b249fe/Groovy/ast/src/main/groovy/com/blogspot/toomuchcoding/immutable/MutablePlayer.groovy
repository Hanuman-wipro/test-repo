package com.blogspot.toomuchcoding.immutable

class MutablePlayer {
    int age
}
