package com.blogspot.toomuchcoding.loggers

import groovy.util.logging.Slf4j

@Slf4j
class PlayerServiceWithLog {
    void someMethod() {
        log.info("THANK GOD!!!!!!!!!")
    }
}
