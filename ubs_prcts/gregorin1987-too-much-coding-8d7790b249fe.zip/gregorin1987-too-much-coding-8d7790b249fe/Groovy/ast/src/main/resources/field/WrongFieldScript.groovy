package field

def map = ["key": "value"]

String someMethod() {
    return map["key"]
}

return someMethod()
