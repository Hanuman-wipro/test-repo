package pl.grzejszczak.marcin.junit.matchers.pojo;

/**
 * Created with IntelliJ IDEA.
 * User: mgrzejszczak
 * Date: 03.01.13
 * Time: 21:05
 */
public class SomeBigPojo {
    private String stringField0;
    private Integer integerField0;
    private Boolean booleanField0;
    private String stringField1;
    private Integer integerField1;
    private Boolean booleanField1;
    private String stringField2;
    private Integer integerField2;
    private Boolean booleanField2;
    private String stringField3;
    private Integer integerField3;
    private Boolean booleanField3;
    private String stringField4;
    private Integer integerField4;
    private Boolean booleanField4;
    private String stringField5;
    private Integer integerField5;
    private Boolean booleanField5;
    private String stringField6;
    private Integer integerField6;
    private Boolean booleanField6;
    private String stringField7;
    private String stringField8;
    private String stringField9;

    public SomeBigPojo(String stringField0, Integer integerField0, Boolean booleanField0, String stringField1, Integer integerField1, Boolean booleanField1, String stringField2, Integer integerField2, Boolean booleanField2, String stringField3, Integer integerField3, Boolean booleanField3, String stringField4, Integer integerField4, Boolean booleanField4, String stringField5, Integer integerField5, Boolean booleanField5, String stringField6, Integer integerField6, Boolean booleanField6, String stringField7, String stringField8, String stringField9) {
        this.stringField0 = stringField0;
        this.integerField0 = integerField0;
        this.booleanField0 = booleanField0;
        this.stringField1 = stringField1;
        this.integerField1 = integerField1;
        this.booleanField1 = booleanField1;
        this.stringField2 = stringField2;
        this.integerField2 = integerField2;
        this.booleanField2 = booleanField2;
        this.stringField3 = stringField3;
        this.integerField3 = integerField3;
        this.booleanField3 = booleanField3;
        this.stringField4 = stringField4;
        this.integerField4 = integerField4;
        this.booleanField4 = booleanField4;
        this.stringField5 = stringField5;
        this.integerField5 = integerField5;
        this.booleanField5 = booleanField5;
        this.stringField6 = stringField6;
        this.integerField6 = integerField6;
        this.booleanField6 = booleanField6;
        this.stringField7 = stringField7;
        this.stringField8 = stringField8;
        this.stringField9 = stringField9;
    }

    public String getStringField0() {
        return stringField0;
    }

    public void setStringField0(String stringField0) {
        this.stringField0 = stringField0;
    }

    public Integer getIntegerField0() {
        return integerField0;
    }

    public void setIntegerField0(Integer integerField0) {
        this.integerField0 = integerField0;
    }

    public Boolean getBooleanField0() {
        return booleanField0;
    }

    public void setBooleanField0(Boolean booleanField0) {
        this.booleanField0 = booleanField0;
    }

    public String getStringField1() {
        return stringField1;
    }

    public void setStringField1(String stringField1) {
        this.stringField1 = stringField1;
    }

    public Integer getIntegerField1() {
        return integerField1;
    }

    public void setIntegerField1(Integer integerField1) {
        this.integerField1 = integerField1;
    }

    public Boolean getBooleanField1() {
        return booleanField1;
    }

    public void setBooleanField1(Boolean booleanField1) {
        this.booleanField1 = booleanField1;
    }

    public String getStringField2() {
        return stringField2;
    }

    public void setStringField2(String stringField2) {
        this.stringField2 = stringField2;
    }

    public Integer getIntegerField2() {
        return integerField2;
    }

    public void setIntegerField2(Integer integerField2) {
        this.integerField2 = integerField2;
    }

    public Boolean getBooleanField2() {
        return booleanField2;
    }

    public void setBooleanField2(Boolean booleanField2) {
        this.booleanField2 = booleanField2;
    }

    public String getStringField3() {
        return stringField3;
    }

    public void setStringField3(String stringField3) {
        this.stringField3 = stringField3;
    }

    public Integer getIntegerField3() {
        return integerField3;
    }

    public void setIntegerField3(Integer integerField3) {
        this.integerField3 = integerField3;
    }

    public Boolean getBooleanField3() {
        return booleanField3;
    }

    public void setBooleanField3(Boolean booleanField3) {
        this.booleanField3 = booleanField3;
    }

    public String getStringField4() {
        return stringField4;
    }

    public void setStringField4(String stringField4) {
        this.stringField4 = stringField4;
    }

    public Integer getIntegerField4() {
        return integerField4;
    }

    public void setIntegerField4(Integer integerField4) {
        this.integerField4 = integerField4;
    }

    public Boolean getBooleanField4() {
        return booleanField4;
    }

    public void setBooleanField4(Boolean booleanField4) {
        this.booleanField4 = booleanField4;
    }

    public String getStringField5() {
        return stringField5;
    }

    public void setStringField5(String stringField5) {
        this.stringField5 = stringField5;
    }

    public Integer getIntegerField5() {
        return integerField5;
    }

    public void setIntegerField5(Integer integerField5) {
        this.integerField5 = integerField5;
    }

    public Boolean getBooleanField5() {
        return booleanField5;
    }

    public void setBooleanField5(Boolean booleanField5) {
        this.booleanField5 = booleanField5;
    }

    public String getStringField6() {
        return stringField6;
    }

    public void setStringField6(String stringField6) {
        this.stringField6 = stringField6;
    }

    public Integer getIntegerField6() {
        return integerField6;
    }

    public void setIntegerField6(Integer integerField6) {
        this.integerField6 = integerField6;
    }

    public Boolean getBooleanField6() {
        return booleanField6;
    }

    public void setBooleanField6(Boolean booleanField6) {
        this.booleanField6 = booleanField6;
    }

    public String getStringField7() {
        return stringField7;
    }

    public void setStringField7(String stringField7) {
        this.stringField7 = stringField7;
    }

    public String getStringField8() {
        return stringField8;
    }

    public void setStringField8(String stringField8) {
        this.stringField8 = stringField8;
    }

    public String getStringField9() {
        return stringField9;
    }

    public void setStringField9(String stringField9) {
        this.stringField9 = stringField9;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("SomeBigPojo");
        sb.append("{stringField0='").append(stringField0).append('\'');
        sb.append(", integerField0=").append(integerField0);
        sb.append(", booleanField0=").append(booleanField0);
        sb.append(", stringField1='").append(stringField1).append('\'');
        sb.append(", integerField1=").append(integerField1);
        sb.append(", booleanField1=").append(booleanField1);
        sb.append(", stringField2='").append(stringField2).append('\'');
        sb.append(", integerField2=").append(integerField2);
        sb.append(", booleanField2=").append(booleanField2);
        sb.append(", stringField3='").append(stringField3).append('\'');
        sb.append(", integerField3=").append(integerField3);
        sb.append(", booleanField3=").append(booleanField3);
        sb.append(", stringField4='").append(stringField4).append('\'');
        sb.append(", integerField4=").append(integerField4);
        sb.append(", booleanField4=").append(booleanField4);
        sb.append(", stringField5='").append(stringField5).append('\'');
        sb.append(", integerField5=").append(integerField5);
        sb.append(", booleanField5=").append(booleanField5);
        sb.append(", stringField6='").append(stringField6).append('\'');
        sb.append(", integerField6=").append(integerField6);
        sb.append(", booleanField6=").append(booleanField6);
        sb.append(", stringField7='").append(stringField7).append('\'');
        sb.append(", stringField8='").append(stringField8).append('\'');
        sb.append(", stringField9='").append(stringField9).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
