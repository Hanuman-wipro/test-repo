package pl.grzejszczak.marcin.junit.matchers.pojo;

/**
 * Created with IntelliJ IDEA.
 * User: mgrzejszczak
 * Date: 03.01.13
 * Time: 23:22
 */
public interface SomePojoConstants {
    int STRING_FIELD_0_LENGTH = 1;
    int STRING_FIELD_1_LENGTH = 2;
    int STRING_FIELD_2_LENGTH = 3;
    int STRING_FIELD_3_LENGTH = 4;
    int STRING_FIELD_4_LENGTH = 5;
    int STRING_FIELD_5_LENGTH = 6;
    int STRING_FIELD_6_LENGTH = 7;
    int STRING_FIELD_7_LENGTH = 8;
    int STRING_FIELD_8_LENGTH = 9;
    int STRING_FIELD_9_LENGTH = 10;
}
