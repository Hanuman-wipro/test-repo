package pl.grzejszczak.marcin.aop.ui;

public abstract class UIComponent {
	protected String componentName;

	protected String getComponentName() {
		return componentName;
	}

}
