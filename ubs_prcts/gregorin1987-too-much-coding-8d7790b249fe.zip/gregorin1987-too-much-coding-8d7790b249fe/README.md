# DEPRECATED #

Hi guys!

The most uptodate repository is available at Github here - https://github.com/marcingrzejszczak/too-much-coding