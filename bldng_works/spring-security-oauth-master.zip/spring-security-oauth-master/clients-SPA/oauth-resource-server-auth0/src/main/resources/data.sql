insert into color
values(1001, 'red');

insert into color
values(1002, 'green');

insert into color
values(1003, 'blue');