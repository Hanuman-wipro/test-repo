package com.baeldung.clientjsonlyreact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientJsOnlyReactApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientJsOnlyReactApplication.class, args);
    }

}
