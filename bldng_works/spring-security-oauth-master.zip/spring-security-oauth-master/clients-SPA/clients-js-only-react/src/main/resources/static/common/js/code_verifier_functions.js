function generate_code_verifier() {
  return random_string(48);
}
