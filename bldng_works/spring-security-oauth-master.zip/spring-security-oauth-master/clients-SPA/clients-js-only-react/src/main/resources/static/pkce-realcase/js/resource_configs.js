const RESOURCE_CONFIGS = {
  SAVE_COLOR_URL: 'http://localhost:8081/colors',
  DELETE_COLOR_URL: 'http://localhost:8081/colors/{id}',
  GET_COLORS_URL: 'http://localhost:8081/colors',
}

window.RESOURCE_CONFIGS = RESOURCE_CONFIGS;