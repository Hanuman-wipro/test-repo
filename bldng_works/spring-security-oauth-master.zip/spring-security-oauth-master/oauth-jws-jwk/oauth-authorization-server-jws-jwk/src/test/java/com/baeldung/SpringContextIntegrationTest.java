package com.baeldung;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringContextIntegrationTest {

    @Test
    public void whenContextInitializes_thenNoExceptionsTriggered() throws Exception {

    }
}
